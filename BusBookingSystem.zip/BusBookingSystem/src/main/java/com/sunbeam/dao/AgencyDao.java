//package com.sunbeam.dao;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.sunbeam.entity.Agency;
//
//public interface AgencyDao extends JpaRepository<Agency, Long> {
//
//}
