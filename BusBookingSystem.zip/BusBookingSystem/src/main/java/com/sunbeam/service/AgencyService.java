//package com.sunbeam.service;
//
//import com.sunbeam.dto.AgencyDto;
//
//public interface AgencyService {
//
//	public String addAgency (AgencyDto dto);
//	
//}
