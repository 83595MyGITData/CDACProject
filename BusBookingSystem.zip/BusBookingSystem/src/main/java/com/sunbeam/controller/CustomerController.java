package com.sunbeam.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sunbeam.dto.CustomerDto;
import com.sunbeam.dto.ReservationDto;
import com.sunbeam.dto.SearchBusDto;
import com.sunbeam.exceptions.ResourceNotFoundException;
import com.sunbeam.service.BusService;
import com.sunbeam.service.CustomerService;
import com.sunbeam.service.ReservationService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/customers")
public class CustomerController {
	@Autowired	
	private CustomerService customerservice;
	
	@Autowired
	private ReservationService reservationservice;
	
	@Autowired
	private BusService busservice;
	
	@PostMapping("/register")
	public ResponseEntity<?> registerCustomer(@RequestBody CustomerDto dto)
	{
		System.out.println(dto);
		try {
			return ResponseEntity.status(HttpStatus.CREATED).body(customerservice.registerCustomer(dto));
		}
		catch(RuntimeException e){
			
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResourceNotFoundException( e.getMessage()));
			
		}
		
	}
	
	@PostMapping("/seatReservation")
	public ResponseEntity<?> doReservation(@RequestBody ReservationDto dto)
	{
		try {
			return ResponseEntity.status(HttpStatus.CREATED).body(reservationservice.addReservation(dto));
		}
		catch(RuntimeException e){
			
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResourceNotFoundException( e.getMessage()));
			
		}
	}
	
	
	
	@GetMapping("/SearchBus")
	public ResponseEntity<?> getAllBusesBySource(@RequestBody SearchBusDto dto)
	{
		System.out.println(dto.toString());
		try {
			return  ResponseEntity.status(HttpStatus.OK).body(busservice.getAllBusesBySourceAndDest(dto));
			}
		catch(RuntimeException e)
		{
			return  ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		}
		
	}
	


}
