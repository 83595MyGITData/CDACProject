package com.sunbeam.entity;

public enum Gender {
	
	MALE,FEMALE
}
