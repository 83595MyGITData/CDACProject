package com.sunbeam.entity;

public enum BusType {
	
	AC,NON_AC

}
